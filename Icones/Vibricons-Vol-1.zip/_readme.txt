==================================================
Vibricons Volume 1 designed by The Web Design Blog
==================================================

This icon pack includes 15 popular icons and symbols used on the internet. Each icon is a transparent PNG file and is supplied in 128px, 64px, 48px and 32px variations.

These icons are released free of charge and can be used for any personal or commercial purpose without attribution. The icons cannot be repackaged or resold as your own work.

The icons have been designed by The Web Design Blog as a free download for our readers. 

If you would like to spread the word we will be very grateful!

Link: http://www.thewebdesignblog.co.uk

Thanks for downloading :-)